#ifndef __FUNCTIONS__
#define __FUNCTIONS__

void getRandomIndexes(int* index1,int* index2,int size);
int getRandomTwoOrFour();
int checkIfWon(int maxScore,int score);
#endif
