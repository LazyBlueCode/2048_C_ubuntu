#ifndef __ARRAYS__
#define __ARRAYS__

void playGame(int* board, int size, int maxScore);


#endif
